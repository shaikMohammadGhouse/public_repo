package com.poc.mycart.product.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.poc.mycart.product.dto.request.ItemMasterDto;
import com.poc.mycart.product.dto.response.ItemResponseDto;


@Service
public interface ItemService {

	ItemResponseDto getItemDto(String itemCode);
	
	List<ItemResponseDto> listItems(String itemCode,Integer productGroupCode);

	ItemResponseDto addItem(ItemMasterDto itemRequest);
}
