package com.poc.mycart.product.dao;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "item_master")
@Entity
public class ItemMaster implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="item_code", unique=true, nullable= false, length=20)
	private String itemCode;
	
	@Column(name="description", nullable= false, length=100)
	private String description;
	
	@Column(name="produt_group", nullable= false)
	private Integer productGroup;
		
	@Column(name="std_weight", nullable= false, length=50)
	private BigDecimal stdWeight;
	
	@Column(name="produt_group_desc", nullable= false, length=50)
	private String productGroupDesc;
	
	
	
	

}
