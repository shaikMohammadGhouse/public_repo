package com.poc.mycart.product.controller;

import java.util.List;

import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.poc.mycart.core.domain.validator.ValueOfEnum;
import com.poc.mycart.product.dto.request.ItemMasterDto;
import com.poc.mycart.product.dto.response.ItemResponseDto;
import com.poc.mycart.product.service.ItemService;

import io.swagger.annotations.ApiParam;


@RestController("itemController")
@RequestMapping("product/v2/item")
public class ItemController {

	@Autowired
	ItemService empService;
	
	@GetMapping("/")
	public List<ItemResponseDto> getEmployeeList(@RequestParam(required=true) @Pattern(regexp="^[A-Z0-9]{1,20}$") String itemCode,
			@RequestParam(required=true)  Integer productGroupCode){
		
		return empService.listItems(itemCode, productGroupCode);
		
	}
	
	
	@GetMapping("/{itemCode}")
	public ItemResponseDto getEmployee(@PathVariable("itemCode") String itemCode){
		
		return empService.getItemDto(itemCode);
		
	}
	
	@PostMapping("/")
	public ItemResponseDto addProduct(@RequestBody  ItemMasterDto itemRequest){
		
		return empService.addItem(itemRequest);
		
	}

}
