package com.poc.mycart.product;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.UserDetailsServiceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.poc.mycart.core.utils.ApplicationPropertiesUtil;
import com.poc.mycart.core.utils.CommonUtil;

import lombok.extern.slf4j.Slf4j;
@ComponentScan({ "com.poc.mycart" })
@EnableJpaRepositories({ "com.poc.mycart" })
@EnableAutoConfiguration
//@EnableCashing
//@EnableScheduling

@SpringBootApplication(exclude = {UserDetailsServiceAutoConfiguration.class})
@Slf4j
public class ProductServiceApplication {
	
	public static void main(String[] args) {

		//SpringApplication.run(ProductServiceApplication.class, args);
		SpringApplication application=new SpringApplication(ProductServiceApplication.class);
		
		ConfigurableEnvironment env=new StandardEnvironment();
		application.setEnvironment(env);
		ApplicationPropertiesUtil.initApplicationProperties(env);
		application.run(args);
		
	}

	
	@Bean
	public CommandLineRunner commandLineRunner() {
		CommonUtil.printAppInfo();
		return args -> log.trace("");
	}
	
	
	
}
