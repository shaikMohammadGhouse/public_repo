package com.poc.mycart.product.dto.response;

import java.io.Serializable;
import java.math.BigDecimal;



import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ItemResponseDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String itemCode;
	
	private String description;
	
	private Integer productGroup;
		
	private BigDecimal stdWeight;
	
	private String productGroupDesc;
}
