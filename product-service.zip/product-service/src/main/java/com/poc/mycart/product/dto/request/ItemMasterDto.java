package com.poc.mycart.product.dto.request;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper = false)
public class ItemMasterDto {
	

	
	private String itemCode;
	
	private String description;
	
	private Integer productGroup;
		
	private BigDecimal stdWeight;
	
	private String productGroupDesc;


}
