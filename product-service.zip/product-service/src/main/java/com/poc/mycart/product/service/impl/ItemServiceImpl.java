package com.poc.mycart.product.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.poc.mycart.core.exception.ServiceException;
import com.poc.mycart.core.util.MapperUtil;
import com.poc.mycart.product.dao.ItemMaster;
import com.poc.mycart.product.dto.request.ItemMasterDto;
import com.poc.mycart.product.dto.response.ItemResponseDto;
import com.poc.mycart.product.repository.ItemRepository;
import com.poc.mycart.product.service.ItemService;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemRepository itemRepo;
	
	
	@Override
	public ItemResponseDto getItemDto(String itemCode) {
		Optional<ItemMaster> itemDao=itemRepo.findByItemCode(itemCode);
		ItemResponseDto response=null;
		if(itemDao.isPresent()) {
			response=(ItemResponseDto) MapperUtil.getDtoMapping(itemDao, ItemResponseDto.class);
			
		}
		return response;
	}

	@Override
	public List<ItemResponseDto> listItems(String itemCode, Integer productGroupCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ItemResponseDto addItem(ItemMasterDto itemRequest) {
		ItemResponseDto response=null;
		ItemMaster item=(ItemMaster) MapperUtil.getDtoMapping(itemRequest, ItemMaster.class);
		item=itemRepo.save(item);
		if(item !=null) {
			response=(ItemResponseDto) MapperUtil.getDtoMapping(item, ItemResponseDto.class);
			
		}else {
			//throw new ServiceException("no product Found","ERR-PRO-001");
		}
		return response;
	}

}
